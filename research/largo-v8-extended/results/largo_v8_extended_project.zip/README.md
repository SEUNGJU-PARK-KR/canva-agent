# Largo v8 extended historical validation

Purpose: validate the frozen v8 recipe on January 2024-April 2026 with October-December 2023 initial training.

This is DAILY proxy research, not 15:18 to 09:06 executable performance. Current universe and theme membership, incomplete historic news and unknown historic alerts remain limitations.

The old market-cap parser read trading volume as market cap. Corrected inputs are the primary result. Same cached sources were used for the legacy sensitivity comparison.

Directories: input contains immutable candidate/correlation snapshots and metadata; source contains reproducible scripts; output contains primary results; qc contains numerical checks. Heavy original raw archives are separately retained in GitHub Actions for 90 days.

Replay: pip install pandas numpy; python source/evaluate_extended.py --input input/corrected --output replay_output

No live strategy or order function was changed. HTML was generated; browser rendering was not tested in this run.
